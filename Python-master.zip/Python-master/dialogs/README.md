[Quo](https://pypi.org/project/quo) ships with a high level API for displaying dialog boxes to the user for informational purposes, or get input from the user.
