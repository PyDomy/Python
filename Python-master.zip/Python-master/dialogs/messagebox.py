# Use the MessageBox() function to display a simple message box.

from quo.dialog import MessageBox

MessageBox(
    title='Example dialog window',
    text='Do you want to continue?')
