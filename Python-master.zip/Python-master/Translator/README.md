# Python-Translator
## Overview

This is a python script that uses translator module powered by Google and translates words from a language of user's choice to another language of user's choice.

## Author
- [Manisha Gupta](https://manisha069.github.io/)
