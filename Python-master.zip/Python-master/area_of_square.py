# Returns the area of the square with given sides
n = input("Enter the side of the square: ")  # Side length should be given in input
side = float(n)
area = side * side  # calculate area
print("Area of the given square is ", area)
