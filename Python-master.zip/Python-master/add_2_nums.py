# for item in # this python program asks uses for 2 number and returns their sum:

a = int(input("enter first Number: "))
b = int(input("enter second Number: "))
print("sum is:", a+b)
