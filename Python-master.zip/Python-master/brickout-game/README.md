# Brickout-Game in pygame

This is a simple brickout-game. It's includes ball, paddle, brick wall 
and additional collision detection between these objects. Furthermore, logic for winning and losing and
scoring. The game is written in **Python 2**. 

You start the game with ```python game.py```

The game runs with 60 frames per second. 

I used a code sample for the basic structure of pygame from this site [http://programarcadegames.com/](http://programarcadegames.com/)
The site contains a comprehensive introduction in Python and Pygame. In addition many many examples.

