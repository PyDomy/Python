"""  patient_name = "john smith"
age = 20
is_patient_name = True
print(patient_name) """

"""  word = input("Why are you unemployed")
print("Due to lack of " +word) """

"""a = input("Enter 1st Number:")
b = input("Enter 2nd Number:")
sum = float (a) + int (b)
print(sum)
"""
student = "ANKITASDFAHBVGASDNDSDNBFCZCXCNIGL"
print(student.lower())

print(student.find("ASDF"))
