n = int(input("Enter number: "))
if n > 0:
    print("Number is positive")
else:
    print("Number is negative")
