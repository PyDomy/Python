# A simple Voice repeater.

### Run the code and speak something: It will repeat exactly what you said!

### It creates a folder,

### Stores your speech as a sound file,

### And plays it!

### Requirements: Python, SpeechRecognition and playsound
