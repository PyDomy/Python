import turtle 
t = turtle.Turtle() 
t.circle(20) 
t1=turtle.Turtle() 
t1.circle(25) 
