# Currency-Calculator-Dynamic
Currency calculator which will fetch the latest and tell you the exact.

pip installations:-

pip install bs4
pip install requests
pip install pyqt5

thank you for using our currency calculator !
:)
